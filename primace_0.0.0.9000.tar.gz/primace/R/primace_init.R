#' @title Runner file
#' @description initializing app
#' @export
primace_init <- function(){
  shiny::runApp('R/')
}
  