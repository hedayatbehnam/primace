library(testthat)
library(primace)

test_check("primace")
